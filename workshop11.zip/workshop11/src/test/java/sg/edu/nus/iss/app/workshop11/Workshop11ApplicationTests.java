package sg.edu.nus.iss.app.workshop11;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Workshop11ApplicationTests {

	@Test
	void contextLoads() {
	}

}
