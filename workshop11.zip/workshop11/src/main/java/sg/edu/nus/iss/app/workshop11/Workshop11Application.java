package sg.edu.nus.iss.app.workshop11;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Workshop11Application {

	public static void main(String[] args) {
		SpringApplication.run(Workshop11Application.class, args);
	}

}
